// src/middleware/auth.middleware.js
import jwt from 'jsonwebtoken';
import jwtConfig from '../config/jwt.config.js';
import Usuario from '../models/usuario.model.js';

export const verifyToken = async (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader) return res.status(401).json({ success: false, message: 'No se proporcionó token' });

    const token = authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ success: false, message: 'Token mal formado' });

    try {
        const decoded = jwt.verify(token, jwtConfig.secret);
        // Agregar usuario al request
        const usuario = await Usuario.findByPk(decoded.id_usuario);
        if (!usuario) {
            return res.status(401).json({ success: false, message: 'Usuario no encontrado' });
        }
        req.usuario = {
            id: usuario.id_usuario,
            nombre: usuario.nombre_usuario,
            rol: usuario.rol
        };
        next();
    } catch (error) {
        return res.status(401).json({ success: false, message: 'Token inválido o expirado' });
    }
};
